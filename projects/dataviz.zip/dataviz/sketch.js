let walkingData = [
  {
  date: "2019",
  miles: 1792
  },
  {
  date: "2020",
  miles: 1385
  },
  {
  date: "2021",
  miles: 1228
  },
  {
  date: "March 2022",
  miles: 150
  },
  {
  date: "January 2022",
  miles: 88
  },
    {
  date: "February 2021",
  miles: 80
  },
  {
  date: "July 2021",
  miles: 137
  },
  {
  date: "September 2020",
  miles: 48
  },
    {
  date: "April 2020",
  miles: 95
  },
  {
  date: "January 2020",
  miles: 184
  },
    {
  date: "February 2019",
  miles: 114
  },
  {
  date: "July 2019",
  miles: 171
  }
];

let container = document.querySelector(".button");


let segNum = 100;
let segLength = 1;

let button1 = document.querySelector(".button1");
let button2 = document.querySelector(".button2");
let button3 = document.querySelector(".button3");
let button4 = document.querySelector(".button4");
let button5 = document.querySelector(".button5");
let button6 = document.querySelector(".button6");
let button7 = document.querySelector(".button7");
let button8 = document.querySelector(".button8");
let button9 = document.querySelector(".button9");
let button10 = document.querySelector(".button10");


button1.addEventListener("click", changeMayDistance);
button2.addEventListener("click", changeMayDistance2);
button3.addEventListener("click", changeMayDistance3);
button4.addEventListener("click", changeMayDistance4);
button5.addEventListener("click", changeMayDistance5);
button6.addEventListener("click", changeMayDistance6);
button7.addEventListener("click", changeMayDistance7);
button8.addEventListener("click", changeMayDistance8);
button9.addEventListener("click", changeMayDistance9);
button10.addEventListener("click", changeMayDistance10);


// function addActive() {
//   button1.classList.add('active');
//   if (button1.hasClass('active')) {
//     button1.classList.removeClass('active');
//     }
// }



function changeMayDistance() {
  segLength = walkingData[0].miles / 100;
//   if (button1.style.background = 'magenta') {
//      button1.style.backgroundColor = ("yellow");
//      console.log('test');
// } else {
//   console.log('c');
//   button1.style.backgroundColor = ("black");
// }
// addActive();
}



function changeMayDistance2() {
  segLength = walkingData[1].miles / 100;

}

function changeMayDistance3() {
  segLength = walkingData[2].miles / 100;
}

function changeMayDistance4() {
  segLength = walkingData[3].miles / 100;
}

function changeMayDistance5() {
  segLength = walkingData[4].miles / 100;
}

function changeMayDistance6() {
  segLength = walkingData[5].miles / 100;
}

function changeMayDistance7() {
  segLength = walkingData[6].miles / 100;
}

function changeMayDistance8() {
  segLength = walkingData[7].miles / 100;
}

function changeMayDistance9() {
  segLength = walkingData[9].miles / 100;
}

function changeMayDistance10() {
  segLength = walkingData[10].miles / 100;
}

let x = [],
    y = [];

for (let i = 0; i < segNum; i++) {
  x[i] = 0;
  y[i] = 0;
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  strokeWeight(9);
  stroke(255, 100);
}

function draw() {
  background('#0b0500');
  dragSegment(0, mouseX, mouseY);
  for (let i = 0; i < x.length - 1; i++) {
    dragSegment(i + 1, x[i], y[i]);
  }
}

function dragSegment(i, xin, yin) {
  const dx = xin - x[i];
  const dy = yin - y[i];
  const angle = atan2(dy, dx);
  x[i] = xin - cos(angle) * segLength;
  y[i] = yin - sin(angle) * segLength;
  segment(x[i], y[i], angle);
}

function segment(x, y, a) {
  push();
  translate(x, y);
  rotate(a);
  line(0, 0, segLength, 0);
  pop();  
}


// function displayMileage () {
//   button1.innerHTML = walkingData.miles;
// }

// function removeMileage(date) {
//   button1.innterHTML = date.date;
// }


// button1.addEventListener("mouseover", displayMileage);
// button1.addEventListener("mouseleave", removeMileage);

// // walkingData.forEach(displayMileage);
